function add(a, b) {
  return a + b;
}

console.log(add(10, 20));

// Binding fucniton
const addTen = add.bind(null, 10);

// print Binded function
console.log(addTen(20));

let list = ["first", "second"];

for (let i in list) {
  let xLi = document.createElement("li");

  let xTn = document.createTextNode(list[i]);

  let xBtn = document.createElement("button");
  xBtn.innerText = "index";

  xBtn.onclick = function (i) {
    alert("index is : " + i);
  }.bind(null, i);

  xLi.appendChild(xTn);
  xLi.appendChild(xBtn);

  document.getElementById("root").appendChild(xLi);
}
